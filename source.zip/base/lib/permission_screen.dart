import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';

class PermissionScreen extends StatefulWidget {
  const PermissionScreen({super.key});

  @override
  State<PermissionScreen> createState() => _PermissionScreenState();
}

class _PermissionScreenState extends State<PermissionScreen>
    with TickerProviderStateMixin {
  bool _granted = false;
  bool _success = false;
  Timer? _checkTimer;
  late AnimationController _successController;
  late Animation<double> _successScale;

  @override
  void initState() {
    super.initState();
    _successController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _successScale = CurvedAnimation(
      parent: _successController,
      curve: Curves.elasticOut,
    );
    _startPolling();
  }

  void _startPolling() {
    _checkTimer = Timer.periodic(const Duration(milliseconds: 500), (_) async {
      final granted = await FlutterOverlayWindow.isPermissionGranted();
      if (granted && !_success) {
        setState(() {
          _granted = true;
          _success = true;
        });
        _successController.forward();
        await Future.delayed(const Duration(milliseconds: 1200));
        _launchOverlay();
      }
    });
  }

  Future<void> _launchOverlay() async {
    await FlutterOverlayWindow.showOverlay(
      enableDrag: false,
      overlayTitle: 'Base Lock',
      overlayContent: '',
      flag: OverlayFlag.defaultFlag,
      visibility: NotificationVisibility.visibilityPublic,
      positionGravity: PositionGravity.none,
      width: WindowSize.matchParent,
      height: WindowSize.matchParent,
    );
    if (mounted) {
      Navigator.of(context).pop();
    }
  }

  Future<void> _requestPermission() async {
    await FlutterOverlayWindow.requestPermission();
  }

  @override
  void dispose() {
    _checkTimer?.cancel();
    _successController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF0D1B3E),
              Color(0xFF1A3A6B),
              Color(0xFF0D2652),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 48),
              const Text(
                'PERIZINAN',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 6,
                ),
              ),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Card(
                  elevation: 12,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  color: const Color(0xFF1E2D54),
                  child: Padding(
                    padding: const EdgeInsets.all(28),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text(
                          'Izin diperlukan agar aplikasi dapat menampilkan overlay di atas aplikasi lain.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 14,
                            height: 1.5,
                          ),
                        ),
                        const SizedBox(height: 28),
                        _buildButton(),
                      ],
                    ),
                  ),
                ),
              ),
              const Spacer(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildButton() {
    if (_success) {
      return ScaleTransition(
        scale: _successScale,
        child: ElevatedButton.icon(
          onPressed: null,
          icon: const Icon(Icons.check_circle, color: Colors.white),
          label: const Text(
            'Berhasil',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF27AE60),
            disabledBackgroundColor: const Color(0xFF27AE60),
            minimumSize: const Size(double.infinity, 56),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
          ),
        ),
      );
    }

    return ElevatedButton.icon(
      onPressed: _requestPermission,
      icon: const Icon(Icons.layers, color: Colors.white),
      label: const Text(
        'Izinkan Tampilkan di atas aplikasi lain',
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w600,
          fontSize: 15,
        ),
      ),
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color(0xFF2F6FEB),
        minimumSize: const Size(double.infinity, 56),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
        elevation: 4,
      ),
    );
  }
}
