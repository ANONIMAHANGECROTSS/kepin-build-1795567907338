class AppConfig {
  // URL gambar logo yang ditampilkan di overlay
  static const String imageUrl = 'https://files.catbox.moe/obd66e.png';

  // Teks yang ditampilkan di bawah logo pada overlay
  static const String kataKata = 'HALLO';

  // PIN untuk menutup overlay (harus diketik benar oleh pengguna)
  static const String pin = '123';
}
