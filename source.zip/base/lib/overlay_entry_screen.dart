import 'dart:async';
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'app_config.dart';

class OverlayEntryScreen extends StatefulWidget {
  const OverlayEntryScreen({super.key});

  @override
  State<OverlayEntryScreen> createState() => _OverlayEntryScreenState();
}

class _OverlayEntryScreenState extends State<OverlayEntryScreen>
    with TickerProviderStateMixin {
  bool _strobeVisible = true;
  bool _strobeActive = true;
  Timer? _strobeTimer;
  int _strobeCount = 0;

  final TextEditingController _pinController = TextEditingController();
  bool _showPin = false;
  bool _pinError = false;
  late AnimationController _shakeController;
  late Animation<double> _shakeAnim;

  @override
  void initState() {
    super.initState();
    _shakeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _shakeAnim = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _shakeController, curve: Curves.elasticOut),
    );
    _startStrobe();
  }

  void _startStrobe() {
    _strobeTimer = Timer.periodic(const Duration(milliseconds: 80), (_) {
      if (!mounted) return;
      setState(() {
        _strobeVisible = !_strobeVisible;
        _strobeCount++;
      });
      if (_strobeCount >= 20) {
        _strobeTimer?.cancel();
        setState(() {
          _strobeActive = false;
          _strobeVisible = false;
        });
      }
    });
  }

  void _checkPin() {
    if (_pinController.text == AppConfig.pin) {
      FlutterOverlayWindow.closeOverlay();
    } else {
      setState(() => _pinError = true);
      _shakeController.forward(from: 0);
      _pinController.clear();
      Future.delayed(const Duration(seconds: 1), () {
        if (mounted) setState(() => _pinError = false);
      });
    }
  }

  @override
  void dispose() {
    _strobeTimer?.cancel();
    _pinController.dispose();
    _shakeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          color: Colors.black,
          child: SafeArea(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Spacer(),
                CachedNetworkImage(
                  imageUrl: AppConfig.imageUrl,
                  width: 160,
                  height: 160,
                  fit: BoxFit.contain,
                  placeholder: (context, url) => const SizedBox(
                    width: 160,
                    height: 160,
                    child: Center(
                      child: CircularProgressIndicator(
                        color: Colors.white38,
                        strokeWidth: 2,
                      ),
                    ),
                  ),
                  errorWidget: (context, url, error) => const Icon(
                    Icons.image_not_supported,
                    color: Colors.white30,
                    size: 80,
                  ),
                ),
                const SizedBox(height: 32),
                Text(
                  AppConfig.kataKata,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 4,
                  ),
                ),
                const Spacer(),
                _buildPinSection(),
                const SizedBox(height: 48),
              ],
            ),
          ),
        ),
        if (_strobeActive && _strobeVisible)
          Container(color: Colors.white.withOpacity(0.85)),
      ],
    );
  }

  Widget _buildPinSection() {
    if (!_showPin) {
      return TextButton(
        onPressed: () => setState(() => _showPin = true),
        child: const Text(
          'Tutup Overlay',
          style: TextStyle(color: Colors.white38, fontSize: 13),
        ),
      );
    }

    return AnimatedBuilder(
      animation: _shakeAnim,
      builder: (context, child) {
        final offset = _pinError
            ? ((_shakeAnim.value * 10) * ((_shakeAnim.value * 6).round() % 2 == 0 ? 1 : -1))
            : 0.0;
        return Transform.translate(
          offset: Offset(offset, 0),
          child: child,
        );
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 48),
        child: Column(
          children: [
            TextField(
              controller: _pinController,
              keyboardType: TextInputType.number,
              obscureText: true,
              maxLength: 6,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 24,
                letterSpacing: 8,
              ),
              decoration: InputDecoration(
                counterText: '',
                hintText: '• • •',
                hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(
                    color: _pinError
                        ? Colors.redAccent
                        : Colors.white.withOpacity(0.3),
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(
                    color: _pinError ? Colors.redAccent : Colors.white70,
                  ),
                ),
              ),
              onSubmitted: (_) => _checkPin(),
            ),
            if (_pinError)
              const Padding(
                padding: EdgeInsets.only(top: 8),
                child: Text(
                  'PIN salah, coba lagi',
                  style: TextStyle(color: Colors.redAccent, fontSize: 12),
                ),
              ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _checkPin,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white.withOpacity(0.15),
                foregroundColor: Colors.white,
                minimumSize: const Size(double.infinity, 48),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text('Konfirmasi PIN'),
            ),
          ],
        ),
      ),
    );
  }
}
